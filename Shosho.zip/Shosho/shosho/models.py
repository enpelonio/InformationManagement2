from django.db import models
from django.utils.timezone import now

class Person(models.Model):
    person_firstname=models.CharField(max_length=100)
    person_middlename=models.CharField(max_length=100, null=True, blank=True)
    person_lastname=models.CharField(max_length=100)
    street_address=models.CharField(max_length=100, null=True, blank=True)
    brgy_address=models.CharField(max_length=100, null=True)
    city_address=models.CharField(max_length=100)
    province_address=models.CharField(max_length=100)
    zip_address=models.CharField(max_length=20)
    country_address=models.CharField(max_length=100)
    birthdate=models.DateField()
    status=models.CharField(max_length=20)
    gender=models.CharField(max_length=20)
    height=models.IntegerField()
    weight=models.IntegerField()
    religion=models.CharField(max_length=100)
    spouse_firstname=models.CharField(max_length=100, null=True, blank=True)
    spouse_middlename=models.CharField(max_length=100, null=True, blank=True)
    spouse_lastname=models.CharField(max_length=100, null=True, blank=True)
    spouse_occupation=models.CharField(max_length=100, null= True, blank=True)
    number_of_children=models.IntegerField(default='0')
    mother_firstname=models.CharField(max_length=100)
    mother_middlename=models.CharField(max_length=100, null=True, blank=True)
    mother_lastname=models.CharField(max_length=100)
    mother_occupation=models.CharField(max_length=100)
    father_firstname=models.CharField(max_length=100)
    father_middlename=models.CharField(max_length=100, null=True, blank=True)
    father_lastname=models.CharField(max_length=100)
    father_occupation=models.CharField(max_length=100)
    profile_picture=models.ImageField(null=True, blank=True)
    class Meta:
        db_table='Person'

class Customer(Person):
    dateRegistered=models.DateField(default=now)

    class Meta:
        db_table='Customer'

class Product(models.Model):
    sku=models.AutoField(primary_key=True)
    date_registered=models.DateField(default=now)
    product_category=models.CharField(max_length=100)
    product_name=models.CharField(max_length=100)
    product_brand=models.CharField(max_length=100)
    product_color=models.CharField(max_length=100)
    product_size=models.CharField(max_length=100)
    product_price=models.FloatField()
    product_stock=models.IntegerField()
    product_picture=models.ImageField(null=True)
    class Meta:
        db_table='Product'

class Transaction(models.Model):
    employeeId=models.ForeignKey(Customer,null=False,blank=False,on_delete=models.CASCADE)
    product_sku=models.ManyToManyField(Product)

