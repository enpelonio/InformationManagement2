from django.shortcuts import render,redirect
from django.views.generic import View
from .forms import *
from .models import *
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage

# Create your views here.
class LandingView(View):
    def get(self,request):
        #print('get')
        return render(request,'shosho/landing.html')

class RegisterCustomerView(View):
    def get(self,request):
        #print('get')
        return render(request,'shosho/index.html')

    def post(self,request):
        form=CustomerForm(request.POST,request.FILES)
        if form.is_valid():
            fname=request.POST.get("person_firstname")
            mname=request.POST.get("person_middlename")
            lname=request.POST.get("person_lastname")
            street=request.POST.get("street_address")
            brgy=request.POST.get("brgy_address")
            city=request.POST.get("city_address")
            prov=request.POST.get("province_address")
            zipC=request.POST.get("zip_address")
            country=request.POST.get("country_address")
            bDate=request.POST.get("birthdate")
            status=request.POST.get("status")
            gender=request.POST.get("gender")
            sFname=request.POST.get("spouseFName")
            sMname=request.POST.get("spouseMName")
            sLname=request.POST.get("spouseLName")
            sOccu=request.POST.get("spouseOccu")
            noChildren=request.POST.get("numChildren")
            mFname=request.POST.get("mother_firstname")
            mMname=request.POST.get("mother_middlename")
            mLname=request.POST.get("mother_lastname")
            mOccu=request.POST.get("mother_occupation")
            fFname=request.POST.get("father_firstname")
            fMname=request.POST.get("father_middlename")
            fLname=request.POST.get("father_lastname")
            fOccu=request.POST.get("father_occupation")
            height=request.POST.get("height")
            weight=request.POST.get("weight")
            religion=request.POST.get("religion")
            profile_picture=request.FILES.get('fileInput',None)
            if profile_picture is not None and profile_picture != '':
                fs = FileSystemStorage()
                filename = fs.save(profile_picture.name, profile_picture)
                profile_picture = fs.url(filename)
            try:
                noChildren=int(noChildren)
            except ValueError:
                noChildren='0'
            #dont forget to add profile_picture later in constructor
            form=Customer(person_firstname=fname,person_middlename=mname,person_lastname=lname,street_address=street,
                            brgy_address=brgy,city_address=city,province_address=prov,zip_address=zipC,country_address=country,
                            birthdate=bDate,status=status,gender=gender,height=height,weight=weight,religion=religion,spouse_firstname=sFname,
                            spouse_middlename=sMname,spouse_lastname=sLname,spouse_occupation=sOccu,number_of_children=noChildren,
                            mother_firstname=mFname,mother_middlename=mMname,mother_lastname=mLname,mother_occupation=mOccu,
                            father_firstname=fFname,father_middlename=fMname,father_lastname=fLname,father_occupation=fOccu,profile_picture=profile_picture)
            form.save()
            return HttpResponse("Record saved")
        else:
            return HttpResponse("Failed")

class RegisterProductView(View):
    def get(self,request):
        return render(request,'shosho/productRegistration.html')

    def post(self,request):
        form=ProductForm(request.POST)
        if form.is_valid():
            pCategory=request.POST.get("product_category")
            pName=request.POST.get("product_name")
            pSize=request.POST.get("product_size")
            pColor=request.POST.get("product_color")
            pPrice=request.POST.get("product_price")
            pBrand=request.POST.get("product_brand")
            pStock=request.POST.get("product_stock")
            pPicture=request.FILES.get('fileInput',None)
            if pPicture is not None and pPicture != '':
                fs = FileSystemStorage()
                filename = fs.save(pPicture.name, pPicture)
                pPicture = fs.url(filename)
            form=Product(product_category=pCategory,product_name=pName,product_brand=pBrand,product_color=pColor,
                            product_size=pSize,product_price=pPrice,product_stock=pStock,product_picture=pPicture)
            form.save()
            products=Product.objects.all()
            return HttpResponse("Row added!")
        else:
            return HttpResponse("Failed!")

class DashboardProductView(View):
    def get(self,request):
        products=Product.objects.all()
        context={
            'products':products
        }
        return render(request,'shosho/dashboard.html',context)
    
    def post(self,request):
        if request.method =='POST':
            form=ProductForm(request.POST)   
            if 'btnAdd' in request.POST:
                pCategory=request.POST.get("product_category")
                pName=request.POST.get("product_name")
                pSize=request.POST.get("product_size")
                pColor=request.POST.get("product_color")
                pPrice=request.POST.get("product_price")
                pBrand=request.POST.get("product_brand")
                pStock=request.POST.get("product_stock")
                pPicture=request.FILES.get('fileInput',None)
                if pPicture is not None and pPicture != '':
                    fs = FileSystemStorage()
                    filename = fs.save(pPicture.name, pPicture)
                    pPicture = fs.url(filename)
                form=Product(product_category=pCategory,product_name=pName,product_brand=pBrand,product_color=pColor,
                                product_size=pSize,product_price=pPrice,product_stock=pStock,product_picture=pPicture)
                form.save()
                return redirect('dashboard_product_view')
            elif 'btnUpdate' in request.POST:
                pId=request.POST.get("product_id")
                pCategory=request.POST.get("product_category")
                pName=request.POST.get("product_name")
                pSize=request.POST.get("product_size")
                pColor=request.POST.get("product_color")
                pPrice=request.POST.get("product_price")
                pBrand=request.POST.get("product_brand")
                pStock=request.POST.get("product_stock")
                pPicture=request.FILES.get('fileInput_update',None)
                pic=Product.objects.filter(sku=pId)[0].product_picture
                if pPicture is not None and pPicture != '':
                    fs = FileSystemStorage()
                    filename = fs.save(pPicture.name, pPicture)
                    pPicture = fs.url(filename)
                else:
                    pPicture=pic
                #print(pPicture)
                update_product=Product.objects.filter(sku=pId).update(product_category=pCategory,product_name=pName,product_brand=pBrand,product_color=pColor,product_size=pSize,product_price=pPrice,product_stock=pStock,product_picture=pPicture)
                print(update_product)
                return redirect('dashboard_product_view')
            elif 'btnDel' in request.POST:
                pId=request.POST.get("product_id")
                print(pId)
                prod = Product.objects.filter(sku=pId).delete()
                print("Record deleted")
                return redirect('dashboard_product_view')
            else:
                return HttpResponse("not a submit button")
        else:
            return HttpResponse("METHOD != POST")

class Dashboard1View(View):
    def get(self,request):
        return render(request,'shosho/dashboard1.html')

class CustomerBuyView(View):
    def get(self,request):
        products=Product.objects.all()
        context={
            'products':products
        }
        print(context)
        return render(request,'shosho/customer_buy.html',context)
    
 