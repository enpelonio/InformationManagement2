var counter = 0
var totalPrice = 0;

function AddToCart(id) {
    var quantity = document.getElementById("quantity-" + id).value;
    var price = document.getElementById("price-" + id).value;
    var name = document.getElementById("name-" + id).value;
    var brand = document.getElementById("brand-" + id).value;
    var cols = '<tr id="remove-' + id + '">';
    if (counter == 0) {
        document.getElementById("intro").remove();
        document.getElementById("table-cart").innerHTML = '<thead> <tr><th>Sku</th><th>Name</th><th>Quantity</th><th>Price</th></tr></thead>';
    }
    totalPrice += (price * quantity);
    document.getElementById("totalPrice").innerHTML = '<h5>Total Price: ' + totalPrice + '</h5>';
    cols += '<td><input type="text" class="form-control" name="sku-' + counter + '" value=' + id + ' readonly /></td>';
    cols += '<td><input type="text" class="form-control" name="name-' + counter + '" value=' + brand + name + ' readonly /></td>';
    cols += '<td><input type="text" class="form-control" id="quantity' + id + '" name="quantity-' + counter + '" value=' + quantity + ' readonly /></td>';
    cols += '<td><input type="number" class="form-control" id="price' + id + '" name="price-' + counter + '" value=' + price + ' readonly /></td>';
    cols += '<td><input type="button" onclick="RemoveToCart(this.id)" class="ibtnDel btn btn-md btn-danger " id="' + id + '"  value="Remove"></td>';
    document.getElementById("table-cart").innerHTML += "" + cols + "</tr>";
    counter += 1;

}

function RemoveToCart(id) {
    var currentPrice = document.getElementById("price" + id).value;
    var currentQuantity = document.getElementById("quantity" + id).value;
    totalPrice = (totalPrice - (currentPrice * currentQuantity));
    document.getElementById("remove-" + id + "").remove();
    document.getElementById("totalPrice").innerHTML = '<h5>Total Price: ' + totalPrice + '</h5>';
}

$(document).ready(function() {
    var stepCounter = 1;
    var counterElem = 0;
    var counterJun = 0;
    var counterSen = 0;
    var counterCol = 0;
    var counterPost = 0;
    var counterTrain = 0;
    var formIsValid = false;

    var current_fs, next_fs, previous_fs; //fieldsets
    var opacity;
    var firstFieldSet = $("fieldset:eq(0)");
    var secFieldSet = $("fieldset:eq(1)");
    var thirdFieldSet = $("fieldset:eq(2)");

    var quantity = 1;




    $("#add_to_cart").click(function() {
        $("#fileInput").click();
    })


    $("#fr").click(function() {
        $("#fileInput").click();
    })

    $("#fileInput").on("change", function() { readURL(this) });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#profileImage')
                    .attr('src', e.target.result)
                    .width(200)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }




    $(".next").click(function() {
        formIsValid = false;
        if (stepCounter == 1) {
            if ($("#msform")[0].checkValidity()) {
                current_fs = firstFieldSet;
                next_fs = secFieldSet;
                $('#progBar').css('width', '56%');
                formIsValid = true;
            } else {
                $('#finishButton').attr('disabled', false);
                $('#finishButton').click();
                $('#finishButton').attr('disabled', true);
            }
        } else if (stepCounter == 2) {
            if ($("#msform")[0].checkValidity()) {
                current_fs = secFieldSet;
                next_fs = thirdFieldSet;
                $('#progBar').css('width', '100%');
                $('#finishButton').css('background', '#66ff66');
                $('#finishButton').attr('disabled', false);
                formIsValid = true;
            } else {
                $('#finishButton').attr('disabled', false);
                $('#finishButton').click();
                $('#finishButton').attr('disabled', true);
            }
        }
        if (formIsValid) {
            stepCounter++;
            //show the next fieldset
            next_fs.show();
            //hide the current fieldset with style
            current_fs.animate({ opacity: 0 }, {
                step: function(now) {
                    // for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        display: "none",
                        position: "relative",
                    });
                    next_fs.css({ opacity: opacity });
                },
                duration: 600,
            });
        }
    });
    $(".back").click(function() {
        if (stepCounter == 2) {
            current_fs = secFieldSet;
            previous_fs = firstFieldSet;
            $('#progBar').css('width', '28%');
        } else if (stepCounter == 3) {
            current_fs = thirdFieldSet;
            previous_fs = secFieldSet;
            $('#progBar').css('width', '56%');
            $('#finishButton').css('background', '#817e7e');
            $('#finishButton').attr('disabled', true);
        }
        stepCounter--;

        //show the previous fieldset
        previous_fs.show();

        //hide the current fieldset with style
        current_fs.animate({ opacity: 0 }, {
            step: function(now) {
                // for making fielset appear animation
                opacity = 1 - now;

                current_fs.css({
                    display: "none",
                    position: "relative",
                });
                previous_fs.css({ opacity: opacity });
            },
            duration: 600,
        });
    });
    $("#addrowElem").on("click", function() {
        console.log("asdasdasd");
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="text" class="form-control" name="name' + counterElem + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="mail' + counterElem + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="phone' + counterElem + '"/></td>';

        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list-Elem").append(newRow);
        counterElem++;
    });
    $("table.order-list-Elem").on("click", ".ibtnDel", function(event) {
        $(this).closest("tr").remove();
        counterElem -= 1
    });
    $("#addrowJun").on("click", function() {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="text" class="form-control" name="name' + counterJun + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="mail' + counterJun + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="phone' + counterJun + '"/></td>';

        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list-Jun").append(newRow);
        counterJun++;
    });
    $("table.order-list-Jun").on("click", ".ibtnDel", function(event) {
        $(this).closest("tr").remove();
        counterJun -= 1
    });
    $("#addrowSen").on("click", function() {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="text" class="form-control" name="name' + counterSen + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="mail' + counterSen + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="phone' + counterSen + '"/></td>';

        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list-Sen").append(newRow);
        counterSen++;
    });
    $("table.order-list-Sen").on("click", ".ibtnDel", function(event) {
        $(this).closest("tr").remove();
        counterSen -= 1
    });
    $("#addrowCol").on("click", function() {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="text" class="form-control" name="name' + counterCol + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="mail' + counterCol + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="phone' + counterCol + '"/></td>';
        cols += '<td><input type="number" class="form-control"' + counterCol + '"/></td>"'
        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list-Col").append(newRow);
        counterCol++;
    });
    $("table.order-list-Col").on("click", ".ibtnDel", function(event) {
        $(this).closest("tr").remove();
        counterCol -= 1
    });
    $("#addrowPost").on("click", function() {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="text" class="form-control" name="name' + counterPost + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="mail' + counterPost + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="phone' + counterPost + '"/></td>';
        cols += '<td><input type="number" class="form-control"' + counterPost + '"/></td>"'

        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list-Post").append(newRow);
        counterPost++;
    });
    $("table.order-list-Post").on("click", ".ibtnDel", function(event) {
        $(this).closest("tr").remove();
        counterPost -= 1
    });
    $("#addrowTrain").on("click", function() {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="text" class="form-control" name="name' + counterTrain + '"/></td>';
        cols += '<td><input type="text" class="form-control" name="mail' + counterTrain + '"/></td>';
        cols += '<td><input type="date" class="form-control" name="phone' + counterTrain + '"/></td>';
        cols += '<td><input type="text" class="form-control"' + counterTrain + '"/></td>"'

        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list-Train").append(newRow);
        counterTrain++;
    });
    $("table.order-list-Train").on("click", ".ibtnDel", function(event) {
        $(this).closest("tr").remove();
        counterTrain -= 1
    });

    $(".submit").click(function() {
        return false;
    });

});